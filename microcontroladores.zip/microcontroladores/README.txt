_controladores

En esta carpeta se encuentran los archivos que contienen la lógica y funciones
para el manejo de las peticiones http POST y GET. Los controladores también se
encargan de solicitar datos al modelo, procesarlos y enviarlos a la vista.

_modelos

En esta carpeta se encuentan estructuras que contienen datos sobre usuarios y
productos. Estos datos son tomados desde base de datos.

_vistas

En esta carpeta se encuentran las vistas que consisten en el código HTML para la
visualización de los datos.
