<?php

//database_connection.php
//Conecta con la base de datos local de MySQL

$connection = new PDO("mysql:host=localhost; dbname=mcdb", "root", "");


?>
