<?php
//https://www.baulphp.com/llenar-select-html-con-mysql-php-ejemplos/
$mysqli = new mysqli('localhost', 'root', '', 'Microcontroladores');

//Si no hay una sesión iniciada, inicia la sesión          
if (!isset($_SESSION)) { session_start(); }

//Si no hay datos en la sesión de usuario, redirige a la pagina de login
if (!isset($_SESSION['user_admin'])){
	header('Location: index.php');//Aqui lo redireccionas al lugar que quieras.
    die();
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
<title>Microcontroladores</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="/Microcontroladores/css/estilos.css" media="screen" />
</head>
<body>
<header>
  <h2>Microcontroladores</h2>
</header>

<section>
  <nav>
    <ul>
      <li><a href="consulta.php">Consulta</a></li>
	<?php	
	//Si el usuario es administrador muestra la opcion de editar productos
	if ($_SESSION['user_admin']) 
	{
	?>
	  <li><a href="editar_productos.php">Editar productos</a></li>
	<?php
	}
	?>		
		
    </ul>
	<a href="logout.php">Cerrar Sesión</a>
  </nav>
  
  <article>
  
  
  <form method="post" action="consulta.php">
  <table class="default">
  <tr>
    <td>Marca</td>
    <td>	
		<select name="Marca">
			<option value="-All-">-All-</option>
			<?php
			//Selecciona los datos de la tabla productos, sin repetirlos (DISTINCT), y los muestra en la lista de opciones
			$query = $mysqli -> query ("SELECT DISTINCT `Marca` FROM productos ORDER BY `Marca`");
			while ($valores = mysqli_fetch_array($query)) {
				echo '<option value="'.$valores['Marca'].'">'.$valores['Marca'].'</option>';
			}
			?>
		</select>
	</td>
	 <td></td>
	  </tr>

  <tr>
    <td>Modelo</td>
    <td>	
		<select name="Modelo">
			<option value="-All-">-All-</option>
			<?php
			$query = $mysqli -> query ("SELECT DISTINCT `Modelo` FROM productos ORDER BY `Modelo`");
			while ($valores = mysqli_fetch_array($query)) {
				echo '<option value="'.$valores['Modelo'].'">'.$valores['Modelo'].'</option>';
			}
			?>
		</select>
	</td>
    <td></td>
  </tr>
  <tr>
    <td></td>
    <td>Valor M&iacute;nimo</td>
    <td>Valor M&aacute;ximo</td>
  </tr>
  <tr>
    <td>Frecuencia</td>
    <td>
	<select name="Frec_Max_MHZ_1">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `Frec_Max_MHZ` FROM productos ORDER BY `Frec_Max_MHZ`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['Frec_Max_MHZ'].'">'.$valores['Frec_Max_MHZ'].'</option>';
		
		}
        ?>
	</select>
	</td>
    <td>
	<select name="Frec_Max_MHZ_2">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `Frec_Max_MHZ` FROM productos  ORDER BY `Frec_Max_MHZ`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['Frec_Max_MHZ'].'">'.$valores['Frec_Max_MHZ'].'</option>';
		
		}
        ?>
	</select>
	</td>
  </tr>
  
  
  <tr>
    <td>N&uacute;mero pines</td>
    <td>
	<select name="Num_Pines_1">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `Num_Pines` FROM productos ORDER BY `Num_Pines`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['Num_Pines'].'">'.$valores['Num_Pines'].'</option>';
		
		}
        ?>
	</select>
	</td>
    <td>
	<select name="Num_Pines_2">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `Num_Pines` FROM productos ORDER BY `Num_Pines`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['Num_Pines'].'">'.$valores['Num_Pines'].'</option>';
		
		}
        ?>
	</select>
	</td>
  </tr>
  
    <tr>
    <td>Memoria programa</td>
    <td>
	<select name="Mem_Prog_KB_1">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `Mem_Prog_KB` FROM productos ORDER BY `Mem_Prog_KB`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['Mem_Prog_KB'].'">'.$valores['Mem_Prog_KB'].'</option>';
		
		}
        ?>
	</select>
	</td>
    <td>
	<select name="Mem_Prog_KB_2">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `Mem_Prog_KB` FROM productos ORDER BY `Mem_Prog_KB`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['Mem_Prog_KB'].'">'.$valores['Mem_Prog_KB'].'</option>';
		
		}
        ?>
	</select>
	</td>
  </tr>
 
  <tr>
    <td>Ram</td>
    <td>
	<select name="Ram_1">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `Ram` FROM productos ORDER BY `Ram`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['Ram'].'">'.$valores['Ram'].'</option>';
		
		}
        ?>
	</select>
	</td>
    <td>
	<select name="Ram_2">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `Ram` FROM productos ORDER BY `Ram`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['Ram'].'">'.$valores['Ram'].'</option>';
		
		}
        ?>
	</select>
	</td>
  </tr>
 
 <tr>
    <td>EE_Prom</td>
    <td>
	<select name="EE_Prom_1">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `EE_Prom` FROM productos ORDER BY `EE_Prom`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['EE_Prom'].'">'.$valores['EE_Prom'].'</option>';
		
		}
        ?>
	</select>
	</td>
    <td>
	<select name="EE_Prom_2">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `EE_Prom` FROM productos ORDER BY `EE_Prom`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['EE_Prom'].'">'.$valores['EE_Prom'].'</option>';
		
		}
        ?>
	</select>
	</td>
  </tr>
 
  <tr>
    <td>N&uacute;mero ADC</td>
    <td>
	<select name="ADC_1">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `ADC` FROM productos ORDER BY `ADC`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['ADC'].'">'.$valores['ADC'].'</option>';
		
		}
        ?>
	</select>
	</td>
    <td>
	<select name="ADC_2">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `ADC` FROM productos ORDER BY `ADC`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['ADC'].'">'.$valores['ADC'].'</option>';
		
		}
        ?>
	</select>
	</td>
  </tr>
 
   <tr>
    <td>UART</td>
    <td>
	<select name="UART_1">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `UART` FROM productos ORDER BY `UART`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['UART'].'">'.$valores['UART'].'</option>';
		
		}
        ?>
	</select>
	</td>
    <td>
	<select name="UART_2">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `UART` FROM productos ORDER BY `UART`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['UART'].'">'.$valores['UART'].'</option>';
		
		}
        ?>
	</select>
	</td>
  </tr>
 
    <tr>
    <td>I2C</td>
    <td>
	<select name="I2C_1">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `I2C` FROM productos ORDER BY `I2C`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['I2C'].'">'.$valores['I2C'].'</option>';
		
		}
        ?>
	</select>
	</td>
    <td>
	<select name="I2C_2">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `I2C` FROM productos ORDER BY `I2C`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['I2C'].'">'.$valores['I2C'].'</option>';
		
		}
        ?>
	</select>
	</td>
  </tr>
 
    <tr>
    <td>Timer 8 Bits</td>
    <td>
	<select name="Tmr_8_Bits_1">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `Tmr_8_Bits` FROM productos ORDER BY `Tmr_8_Bits`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['Tmr_8_Bits'].'">'.$valores['Tmr_8_Bits'].'</option>';
		
		}
        ?>
	</select>
	</td>
    <td>
	<select name="Tmr_8_Bits_2">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `Tmr_8_Bits` FROM productos ORDER BY `Tmr_8_Bits`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['Tmr_8_Bits'].'">'.$valores['Tmr_8_Bits'].'</option>';
		
		}
        ?>
	</select>
	</td>
  </tr>
 
  <tr>
    <td>Timer 16 Bits</td>
    <td>
	<select name="Tmr_16_Bits_1">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `Tmr_16_Bits` FROM productos ORDER BY `Tmr_16_Bits`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['Tmr_16_Bits'].'">'.$valores['Tmr_16_Bits'].'</option>';
		
		}
        ?>
	</select>
	</td>
    <td>
	<select name="Tmr_16_Bits_2">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `Tmr_16_Bits` FROM productos ORDER BY `Tmr_16_Bits`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['Tmr_16_Bits'].'">'.$valores['Tmr_16_Bits'].'</option>';
		
		}
        ?>
	</select>
	</td>
  </tr>
 
 
   <tr>
    <td>Timer 32 Bits</td>
    <td>
	<select name="Tmr_32_Bits_1">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `Tmr_32_Bits` FROM productos ORDER BY `Tmr_32_Bits`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['Tmr_32_Bits'].'">'.$valores['Tmr_32_Bits'].'</option>';
		
		}
        ?>
	</select>
	</td>
    <td>
	<select name="Tmr_32_Bits_2">
        <option value="-All-">-All-</option>
        <?php
		$query = $mysqli -> query ("SELECT DISTINCT `Tmr_32_Bits` FROM productos ORDER BY `Tmr_32_Bits`");
		while ($valores = mysqli_fetch_array($query)) {
		echo '<option value="'.$valores['Tmr_32_Bits'].'">'.$valores['Tmr_32_Bits'].'</option>';
		
		}
        ?>
	</select>
	</td>
  </tr>
 
</table>
  <input type="submit" value="Buscar"/>
</form>
 
<table>
	<tr>
	<td>id</<td>
	<td>Marca</<td>
	<td>Modelo</<td>
	<td>Frecuencia </<td>
	<td>Num_Pines</<td>
	<td>Mem_Prog_KB</<td>
	<td>Ram</<td>
	<td>EE_Prom</<td>
	<td>ADC</<td>
	<td>UART</<td>
	<td>I2C</<td>
	<td>Timer 8 Bits</<td>
	<td>Timer 16 Bits</<td>
	<td>Timer 32 Bits</<td>
	</tr>
<?php
//Si se ha dado al boton buscar y Si ha recibido los datos de la busqueda muestra
//la tabla de acuerdo a los parametros de busqueda
	//https://stackoverflow.com/questions/17139501/using-post-to-get-select-option-value-from-html/17139538
//Si el texto no dice  ALL, busca por el parámetro seleccionado
		if (empty($where)){
			if ($_POST["Marca"] <> '-All-'){	
				$where="`Marca` = '".$_POST["Marca"]."'"; 
			}
		}
		else{
			if ($_POST["Marca"] <> '-All-'){	
				$where=$where." AND `Marca` = '".$_POST["Marca"]."'"; 
			}
		}
		if (empty($where)){
			if ($_POST["Modelo"] <> '-All-'){	
				$where="`Modelo` = '".$_POST["Modelo"]."'"; 
			}
		}
		else{
			if ($_POST["Modelo"] <> '-All-'){	
				$where=$where." AND `Modelo` = '".$_POST["Modelo"]."'"; 
			}
		}	
		
		//Comparar mayor que o menor que
		//Hay dos listas de opciones por cada parametro numerico
		//para buscar mayor o igual o menor e igual
		if (empty($where)){
			if ($_POST["Frec_Max_MHZ_1"] <> '-All-'){	
				$where="`Frec_Max_MHZ` >= ".$_POST["Frec_Max_MHZ_1"]; 
			}
		}
		else{
			if ($_POST["Frec_Max_MHZ_1"] <> '-All-'){	
				$where=$where." AND `Frec_Max_MHZ` >= ".$_POST["Frec_Max_MHZ_1"]; 
			}
		}	
		if (empty($where)){
			if ($_POST["Frec_Max_MHZ_2"] <> '-All-'){	
				$where="`Frec_Max_MHZ` <= ".$_POST["Frec_Max_MHZ_2"]; 
			}
		}
		else{
			if ($_POST["Frec_Max_MHZ_2"] <> '-All-'){	
				$where=$where." AND `Frec_Max_MHZ` <= ".$_POST["Frec_Max_MHZ_2"]; 
			}
		}	
		//Fin
		//Comparar mayor que o menor que Num_Pines
		if (empty($where)){
			if ($_POST["Num_Pines_1"] <> '-All-'){	
				$where="`Num_Pines` >= ".$_POST["Num_Pines_1"]; 
			}
		}
		else{
			if ($_POST["Num_Pines_1"] <> '-All-'){	
				$where=$where." AND `Num_Pines` >= ".$_POST["Num_Pines_1"]; 
			}
		}	
		if (empty($where)){
			if ($_POST["Num_Pines_2"] <> '-All-'){	
				$where="`Num_Pines` <= ".$_POST["Num_Pines_2"]; 
			}
		}
		else{
			if ($_POST["Num_Pines_2"] <> '-All-'){	
				$where=$where." AND `Num_Pines` <= ".$_POST["Num_Pines_2"]; 
			}
		}	
		//Fin
		//Comparar mayor que o menor que Mem_Prog_KB
		if (empty($where)){
			if ($_POST["Mem_Prog_KB_1"] <> '-All-'){	
				$where="`Mem_Prog_KB` >= ".$_POST["Mem_Prog_KB_1"]; 
			}
		}
		else{
			if ($_POST["Mem_Prog_KB_1"] <> '-All-'){	
				$where=$where." AND `Mem_Prog_KB` >= ".$_POST["Mem_Prog_KB_1"]; 
			}
		}	
		if (empty($where)){
			if ($_POST["Mem_Prog_KB_2"] <> '-All-'){	
				$where="`Mem_Prog_KB` <= ".$_POST["Mem_Prog_KB_2"]; 
			}
		}
		else{
			if ($_POST["Mem_Prog_KB_2"] <> '-All-'){	
				$where=$where." AND `Mem_Prog_KB` <= ".$_POST["Mem_Prog_KB_2"]; 
			}
		}	
		//Fin
				//Comparar mayor que o menor que Ram
		if (empty($where)){
			if ($_POST["Ram_1"] <> '-All-'){	
				$where="`Ram` >= ".$_POST["Ram_1"]; 
			}
		}
		else{
			if ($_POST["Ram_1"] <> '-All-'){	
				$where=$where." AND `Ram` >= ".$_POST["Ram_1"]; 
			}
		}	
		if (empty($where)){
			if ($_POST["Ram_2"] <> '-All-'){	
				$where="`Ram` <= ".$_POST["Ram_2"]; 
			}
		}
		else{
			if ($_POST["Ram_2"] <> '-All-'){	
				$where=$where." AND `Ram` <= ".$_POST["Ram_2"]; 
			}
		}	
		//Fin
		//Comparar mayor que o menor que EE_Prom
		if (empty($where)){
			if ($_POST["EE_Prom_1"] <> '-All-'){	
				$where="`EE_Prom` >= ".$_POST["EE_Prom_1"]; 
			}
		}
		else{
			if ($_POST["EE_Prom_1"] <> '-All-'){	
				$where=$where." AND `EE_Prom` >= ".$_POST["EE_Prom_1"]; 
			}
		}	
		if (empty($where)){
			if ($_POST["EE_Prom_2"] <> '-All-'){	
				$where="`EE_Prom` <= ".$_POST["EE_Prom_2"]; 
			}
		}
		else{
			if ($_POST["EE_Prom_2"] <> '-All-'){	
				$where=$where." AND `EE_Prom` <= ".$_POST["EE_Prom_2"]; 
			}
		}	
		//Fin
				//Comparar mayor que o menor que ADC
		if (empty($where)){
			if ($_POST["ADC_1"] <> '-All-'){	
				$where="`ADC` >= ".$_POST["ADC_1"]; 
			}
		}
		else{
			if ($_POST["ADC_1"] <> '-All-'){	
				$where=$where." AND `ADC` >= ".$_POST["ADC_1"]; 
			}
		}	
		if (empty($where)){
			if ($_POST["ADC_2"] <> '-All-'){	
				$where="`ADC` <= ".$_POST["ADC_2"]; 
			}
		}
		else{
			if ($_POST["ADC_2"] <> '-All-'){	
				$where=$where." AND `ADC` <= ".$_POST["ADC_2"]; 
			}
		}	
		//Fin
				//Comparar mayor que o menor que UART
		if (empty($where)){
			if ($_POST["UART_1"] <> '-All-'){	
				$where="`UART` >= ".$_POST["UART_1"]; 
			}
		}
		else{
			if ($_POST["UART_1"] <> '-All-'){	
				$where=$where." AND `UART` >= ".$_POST["UART_1"]; 
			}
		}	
		if (empty($where)){
			if ($_POST["UART_2"] <> '-All-'){	
				$where="`UART` <= ".$_POST["UART_2"]; 
			}
		}
		else{
			if ($_POST["UART_2"] <> '-All-'){	
				$where=$where." AND `UART` <= ".$_POST["UART_2"]; 
			}
		}	
		//Fin
						//Comparar mayor que o menor que I2C
		if (empty($where)){
			if ($_POST["I2C_1"] <> '-All-'){	
				$where="`I2C` >= ".$_POST["I2C_1"]; 
			}
		}
		else{
			if ($_POST["I2C_1"] <> '-All-'){	
				$where=$where." AND `I2C` >= ".$_POST["I2C_1"]; 
			}
		}	
		if (empty($where)){
			if ($_POST["I2C_2"] <> '-All-'){	
				$where="`I2C` <= ".$_POST["I2C_2"]; 
			}
		}
		else{
			if ($_POST["I2C_2"] <> '-All-'){	
				$where=$where." AND `I2C` <= ".$_POST["I2C_2"]; 
			}
		}	
		//Fin
						//Comparar mayor que o menor que Tmr_8_Bits
		if (empty($where)){
			if ($_POST["Tmr_8_Bits_1"] <> '-All-'){	
				$where="`Tmr_8_Bits` >= ".$_POST["Tmr_8_Bits_1"]; 
			}
		}
		else{
			if ($_POST["Tmr_8_Bits_1"] <> '-All-'){	
				$where=$where." AND `Tmr_8_Bits` >= ".$_POST["Tmr_8_Bits_1"]; 
			}
		}	
		if (empty($where)){
			if ($_POST["Tmr_8_Bits_2"] <> '-All-'){	
				$where="`Tmr_8_Bits` <= ".$_POST["Tmr_8_Bits_2"]; 
			}
		}
		else{
			if ($_POST["Tmr_8_Bits_2"] <> '-All-'){	
				$where=$where." AND `Tmr_8_Bits` <= ".$_POST["Tmr_8_Bits_2"]; 
			}
		}	
		//Fin
	//Comparar mayor que o menor que Tmr_16_Bits
		if (empty($where)){
			if ($_POST["Tmr_16_Bits_1"] <> '-All-'){	
				$where="`Tmr_16_Bits` >= ".$_POST["Tmr_16_Bits_1"]; 
			}
		}
		else{
			if ($_POST["Tmr_16_Bits_1"] <> '-All-'){	
				$where=$where." AND `Tmr_16_Bits` >= ".$_POST["Tmr_16_Bits_1"]; 
			}
		}	
		if (empty($where)){
			if ($_POST["Tmr_16_Bits_2"] <> '-All-'){	
				$where="`Tmr_16_Bits` <= ".$_POST["Tmr_16_Bits_2"]; 
			}
		}
		else{
			if ($_POST["Tmr_16_Bits_2"] <> '-All-'){	
				$where=$where." AND `Tmr_16_Bits` <= ".$_POST["Tmr_16_Bits_2"]; 
			}
		}	
		//Fin
			//Comparar mayor que o menor que Tmr_32_Bits
		if (empty($where)){
			if ($_POST["Tmr_32_Bits_1"] <> '-All-'){	
				$where="`Tmr_32_Bits` >= ".$_POST["Tmr_32_Bits_1"]; 
			}
		}
		else{
			if ($_POST["Tmr_32_Bits_1"] <> '-All-'){	
				$where=$where." AND `Tmr_32_Bits` >= ".$_POST["Tmr_32_Bits_1"]; 
			}
		}	
		if (empty($where)){
			if ($_POST["Tmr_32_Bits_2"] <> '-All-'){	
				$where="`Tmr_32_Bits` <= ".$_POST["Tmr_32_Bits_2"]; 
			}
		}
		else{
			if ($_POST["Tmr_32_Bits_2"] <> '-All-'){	
				$where=$where." AND `Tmr_32_Bits` <= ".$_POST["Tmr_32_Bits_2"]; 
			}
		}	
		//Fin
		if (!empty($where)){
			$where="SELECT * FROM productos WHERE ".$where; 
		}
		else{
			$where="SELECT * FROM productos"; 
		}
			
			//Esta linea es para mostrar la condicion sql a ejecutar
			echo $where;
	}
else{
	//Si es la primera vez que inicia la pagina, muestra todos los productos
	$where="SELECT * FROM productos"; 
	}


	//Mostrar la tabla de busqueda
	$query = $mysqli -> query ($where);
//Con este ciclo muestra cada uno de los valores, en base a la seleccion 
//$query
	while ($valores = mysqli_fetch_array($query)) 
	{
	echo '<tr>';
	echo '<td>'.$valores['id'].'</<td>';
	echo '<td>'.$valores['Marca'].'</<td>';
	echo '<td>'.$valores['Modelo'].'</<td>';
	echo '<td>'.$valores['Frec_Max_MHZ'].'</<td>';
	echo '<td>'.$valores['Num_Pines'].'</<td>';
	echo '<td>'.$valores['Mem_Prog_KB'].'</<td>';
	echo '<td>'.$valores['Ram'].'</<td>';
	echo '<td>'.$valores['EE_Prom'].'</<td>';
	echo '<td>'.$valores['ADC'].'</<td>';
	echo '<td>'.$valores['UART'].'</<td>';
	echo '<td>'.$valores['I2C'].'</<td>';
	echo '<td>'.$valores['Tmr_8_Bits'].'</<td>';
	echo '<td>'.$valores['Tmr_16_Bits'].'</<td>';
	echo '<td>'.$valores['Tmr_32_Bits'].'</<td>';
	echo '</tr>';
	}
 ?>
		 
</table>

</article>
</section>

<footer>
  <p>Footer</p>
</footer>

</body>
</html>
